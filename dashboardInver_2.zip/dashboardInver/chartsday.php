<?php
  ini_set('date.timezone','America/Guatemala');
  //Primer ingreso
  if (!isset($_POST['graf']) && !isset($_POST['grafd']) && !isset($_POST['grafm'])) {
    # code...
    $anio = date("Y");
    $mes = date("m");
    $dia = date("d");
    $ValGraf = $anio.'-'.$mes.'-'.$dia;
  }//Datos dia Actual -- a-a d-a m-a
  elseif ($_POST['graf']==0  && $_POST['grafd']==0 && $_POST['grafm']==0) {
    # code...
    $anio = date("Y");
    $mes = date("m");
    $dia = date("d");
      $ValGraf = $anio.'-'.$mes.'-'.$dia;
  }//Datos donde fecha actual y dia elegido -- a-a d-e m-a
  elseif ($_POST['graf']==0  && $_POST['grafd']!=0 && $_POST['grafm']==0) {
    # code...
    $anio = date("Y");
    $mes = date("m");

      $ValGraf = $anio.'-'.$mes.'-'.$_POST['grafd'];
  }//Datos donde anio actual y dia actual y mes elegido -- a-a d-a m-e
  elseif ($_POST['graf']==0  && $_POST['grafd']==0 && $_POST['grafm']!=0) {
    # code...
    $anio = date("Y");
    $dia = date("d");
      $ValGraf = $anio.'-'.$_POST['grafm'].'-'.$dia;
  }//a-e d-a m-a 4
  elseif ($_POST['graf']!=0  && $_POST['grafd']==0 && $_POST['grafm']==0) {
    # code...

    $mes = date("m");
    $dia = date("d");
      $ValGraf = $_POST['graf'].'-'.$mes.'-'.$dia;
  }//a-e d-e m-a 5
  elseif ($_POST['graf']!=0  && $_POST['grafd']!=0 && $_POST['grafm']==0) {
    # code...
      $mes = date("m");
        $ValGraf = $_POST['graf'].'-'.$mes.'-'.$_POST['grafd'];
  }//a-e d-a m-e 6
  elseif ($_POST['graf']!=0  && $_POST['grafd']==0 && $_POST['grafm']!=0) {
    # code...
    $dia = date("d");
    $ValGraf = $_POST['graf'].'-'.$_POST['grafm'].'-'.$dia;
  }//a-a d-e m-e
  elseif ($_POST['graf']==0  && $_POST['grafd']!=0 && $_POST['grafm']!=0) {
    # code...
    $anio = date("Y");
    $ValGraf = $anio.'-'.$_POST['grafm'].'-'.$_POST['grafd'];
  }
  else {
    # code...
          $ValGraf = $_POST['graf'].'-'.$_POST['grafm'].'-'.$_POST['grafd'];
  }
 ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Bootstrap PAG -->
    <link href="css/jquery.dataTables.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script>
      function recargar(){
        location.reload();
      }
    </script>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
      <!--          <a class="navbar-brand" href="index.html">Administrador Invernadero</a>   -->
                <?php
                echo '<a class="navbar-brand" href="index.html">Administrador Invernadero - Fecha: '.$ValGraf.'</a>;'
                 ?>
            </div>
            <!-- Top Menu Items
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading"><strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-footer">
                            <a href="#">Read All New Messages</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>-->
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>

                  <li class="active">
                      <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-bar-chart-o"></i>Historial Temperatura/Humedad <i class="fa fa-fw fa-caret-down"></i></a>
                      <ul id="demo" class="collapse">
                          <li>
                              <a href="charts.php">Historial Mensual</a>
                          </li>
                          <li class="active">
                              <a href="chartsday.php">Historial Diario</a>
                          </li>
                      </ul>
                  </li>
                  <li>
                          <a href="#"><i class="fa fa-fw fa-sliders"></i> Admin. de Proyectos</a>
                      </li>
              <!--       <li>
                           <a href="blank-page.html"><i class="fa fa-fw fa-file"></i> Blank Page</a>
                    </li>
                    <li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                    </li> -->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Historial Temperatura / Humedad
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-bar-chart-o"></i> Historial Diario
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <!-- Flot Charts
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="page-header">Flot Charts</h2>
                        <p class="lead">Flot is a pure JavaScript plotting library for jQuery, with a focus on simple usage, attractive looks and interactive features. For full usage instructions and documentation for Flot Charts, visit <a href="http://www.flotcharts.org/">http://www.flotcharts.org/</a>.</p>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Line Graph Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-line-chart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Pie Chart Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-pie-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Multiple Axes Line Graph Example with Tooltips and Raw Data</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-multiple-axes-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Moving Line Chart</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-moving-line-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Bar Graph with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-bar-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 /.row -->
                 <!-- Conexion a Base de datos-->
           <?php
                 $dbserver = 'localhost';
                 $dbuser = 'root';
                 $password = '';
                 $dbname = 'sensorial';

                 $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                 if($database->connect_errno) {
                   die("No se pudo conectar a la base de datos");
                 }

                 mysqli_close($database);
          ?>
                <!-- Morris Charts -->
                <div class="row">
                  <form method="post">
                    <select required name="grafd" class="form-control">
                      <option value="0">Día Actual</option>
                      <?php
                        for ($i=1; $i <=31 ; $i++) {
                          # code...
                          if ($i<10) {
                            # code...
                              echo '<option value="0'.$i.'">'.$i.'</option>';
                          }
                          elseif ($i>9) {
                            # code...
                            echo '<option value="'.$i.'">'.$i.'</option>';
                          }

                        }
                        ?>
                    </select>
                    <select required name="grafm" class="form-control">
                      <option value="0">Mes Actual</option>
                      <?php
                      for ($i=1; $i <= 12; $i++) {
                        # code...
                        switch ($i){
                        case 1:
                          $mesName = "Enero";
                          break;
                        case 2:
                          $mesName = "Febrero";
                          break;
                        case 3:
                          $mesName = "Marzo";
                          break;
                        case 4:
                          $mesName = "Abril";
                          break;
                        case 5:
                          $mesName = "Mayo";
                          break;
                        case 6:
                          $mesName = "Junio";
                          break;
                        case 7:
                          $mesName = "Julio";
                          break;
                        case 8:
                          $mesName = "Agosto";
                          break;
                        case 9:
                          $mesName = "Septiembre";
                          break;
                        case 10:
                          $mesName = "Octubre";
                          break;
                        case 11:
                          $mesName = "Noviembre";
                          break;
                        case 12:
                          $mesName = "Diciembre";
                          break;}
                          if ($i<10) {
                            # code...
                              echo '<option value="0'.$i.'">'.$mesName.'</option>';
                          }
                          elseif ($i>9) {
                            # code...
                            echo '<option value="'.$i.'">'.$mesName.'</option>';
                          }

                      } ?>
                    </select>
                      <select required name="graf" class="form-control">
                        <option value="0">Año Acual</option>
                        <?php
                        $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                        if($database->connect_errno) {
                          die("No se pudo conectar a la base de datos");
                        }

                        $query1 = "SELECT DISTINCT YEAR(A.TIEMPO) AS 'ANIO'  FROM `STATUS_RECORD`A
                                    ORDER BY  YEAR(TIEMPO) ASC";

                        $queryC1= $database->query($query1);

                        while ($registro1 = $queryC1->fetch_array( MYSQLI_BOTH)) {
                          # code...
                        /*  $mesActual = $registro1['MES'];
                          switch ($mesActual){
                          case 1:
                            $mesName = "Enero";
                            break;
                          case 2:
                            $mesName = "Febrero";
                            break;
                          case 3:
                            $mesName = "Marzo";
                            break;
                          case 4:
                            $mesName = "Abril";
                            break;
                          case 5:
                            $mesName = "Mayo";
                            break;
                          case 6:
                            $mesName = "Junio";
                            break;
                          case 7:
                            $mesName = "Julio";
                            break;
                          case 8:
                            $mesName = "Agosto";
                            break;
                          case 9:
                            $mesName = "Septiembre";
                            break;
                          case 10:
                            $mesName = "Octubre";
                            break;
                          case 11:
                            $mesName = "Noviembre";
                            break;
                          case 12:
                            $mesName = "Diciembre";
                            break;
                        }*/
                          echo '<option value="'.$registro1['ANIO'].'">'.$registro1['ANIO'].'</option>';
                        }
                           mysqli_close($database);
                         ?>
                      </select>
                    </br>
                    <center>
                      <input type="submit" name="filtrar" value="Selecionar" class="btn btn-info"/>
                    </center>
                  </form>
                    <div class="col-lg-12">
                        <h2 class="page-header">Grafica Diaria de Temperatura y Humedad</h2>
                        <p class="lead">Las graficas representada por lineas, en el eje Y son valores de Temperatura o Humedad
                          (Los cuales son un promedio de todos los datos recolectados en una hora), en el eje X representa las horas.
                        </p>
                        </br>
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Proyectos en el día</h3>
                            </div>
                            <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="table table-hover">
                                      <thead>
                                          <tr>
                                              <th>Nombre del Proyecto</th>
                                              <th>Descripcion</th>
                                              <th>Estado</th>

                                          </tr>
                                      </thead>
                                      <tbody>
                                          <?php
                                          $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                                          if($database->connect_errno) {
                                            die("No se pudo conectar a la base de datos");
                                          }

                                          $query4 = "SELECT DISTINCT A.PROY_CODE AS 'COD', B.NOMBRE AS 'NAME', B.DESCRIPTION AS 'DESCRIP', B.ACTIVO AS 'ACT'
                                          FROM `STATUS_RECORD` A
                                          INNER JOIN PROYECTO B ON B.PROY_CODE = A.PROY_CODE
                                          WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."' AND '".$ValGraf."'";

                                          $queryC4 = $database->query($query4);

                                           $row_cnt = $queryC4->num_rows;
                                          if ($row_cnt == 0) {
                                            # code...
                                            $sqds = 0;
                                          }else {
                                            # code...
                                            $sqds = 1;
                                          }
                                          while ($registro4 = $queryC4->fetch_array( MYSQLI_BOTH)) {
                                            # code...
                                            $activo = $registro4['ACT'];

                                            switch ($activo) {
                                              case 1:
                                                # code...
                                                 $valty = "Activo";
                                                break;
                                              case 0:
                                                  # code...
                                                 $valty = "No Activo";
                                                break;

                                            }
                                            echo '<tr>
                                                <td>'.$registro4['NAME'].'</td>
                                                <td>'.$registro4['DESCRIP'].'</td>
                                                <td>'.$valty.'</td>
                                            </tr>';
                                          }
                                          mysqli_close($database);

                                          ?>
                                      </tbody>
                                  </table>
                              </div>
                            </div>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                              <?php
                                echo '<h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Grafica del '.$ValGraf.' (Temperatura por dias) </h3>';
                              ?>
                            </div>
                            <div class="panel-body">
                              <?php
                              if ($sqds == 0) {
                                # code...
                                echo "No existen datos";
                              }elseif ($sqds == 1) {
                                # code...
                                  echo '<div id="morris-area-chart"></div>';
                              }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                              <?php
                                echo '<h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Grafica del '.$ValGraf.' (Humedad Relativa por dias) </h3>';
                              ?>
                            </div>
                            <div class="panel-body">
                              <?php
                              if ($sqds == 0) {
                                # code...
                                echo "No existen datos";
                              }elseif ($sqds == 1) {
                                # code...
                                  echo '<div id="morris-chart"></div>';
                              }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Donut Chart Example</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart"></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Line Graph Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-line-chart"></div>

                            </div>
                        </div>
                    </div>

                </div>-->
                <!-- /.row -->

              <div class="col-lg-12">
              <div class="panel panel-green">
                  <div class="panel-heading">
                      <h3 class="panel-title">Datos en el día (Ultimos 20 datos ingresados)</h3>
                  </div>
                  <div class="panel-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nombre del Proyecto</th>
                                    <th>Temperatura</th>
                                    <th>Humedad Relativa</th>
                                    <th>Estado de Nebulizadores</th>
                                    <th>Estado de Extractores</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                                if($database->connect_errno) {
                                  die("No se pudo conectar a la base de datos");
                                }

                                $query4 = "SELECT B.`NOMBRE` AS 'CODE', A.`TEMPERATURA` AS 'TEM',  A.`HUMEDAD` AS 'HUM',
                                 A.`EXTRACTORES` AS 'EXT', A.`NEBULIZADORES` AS 'NUE' FROM `STATUS_RECORD` A
                                 INNER JOIN PROYECTO B ON B.`PROY_CODE` = A.`PROY_CODE`
                                          WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."' AND '".$ValGraf."'
                                          ORDER BY `TIEMPO`  DESC LIMIT 20";

                                $queryC4 = $database->query($query4);

                                while ($registro4 = $queryC4->fetch_array( MYSQLI_BOTH)) {
                                  # code...
                                  $actEXT = $registro4['EXT'];
                                  $actNUE = $registro4['NUE'];

                                  switch ($actEXT) {
                                    case 1:
                                      # code...
                                       $valEXT = "Activo";
                                      break;
                                    case 0:
                                        # code...
                                       $valEXT = "No Activo";
                                      break;

                                  }
                                  switch ($actNUE) {
                                    case 1:
                                      # code...
                                       $valNUE = "Activo";
                                      break;
                                    case 0:
                                        # code...
                                       $valNUE = "No Activo";
                                      break;

                                  }
                                  echo '<tr>
                                      <td>'.$registro4['CODE'].'</td>
                                      <td>'.$registro4['TEM'].'</td>
                                      <td>'.$registro4['HUM'].'</td>
                                      <td>'.$valNUE.'</td>
                                      <td>'.$valEXT.'</td>
                                  </tr>';
                                }
                                mysqli_close($database);

                                ?>
                            </tbody>
                        </table>
                    </div>
                  </div>
              </div>
              </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->

    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>

<!--    <script src="js/plugins/morris/morris-data.js"></script> -->
<?php
if ($sqds ==1) {
  # code...

$database = new mysqli($dbserver, $dbuser, $password, $dbname);

if($database->connect_errno) {
  die("No se pudo conectar a la base de datos");
}
$DatoScript = "<script>
  Morris.Line({

    element: 'morris-area-chart',

    data: [";
$query2 = "SELECT ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  HOUR(`TIEMPO`) AS 'HORA',
MINUTE(`TIEMPO`) AS 'MIN', `TIEMPO` AS 'TH', DATE(`TIEMPO`) AS 'FECHA'
FROM `STATUS_RECORD`
WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."' AND '".$ValGraf."'
GROUP BY HOUR(TIEMPO)
ORDER BY TIEMPO ASC";

$queryC2 = $database->query($query2);

while ($registro2 = $queryC2->fetch_array( MYSQLI_BOTH)) {
  # code...
  $ULTIMEDAY = $registro2['HORA'];
  $ULTMES = $registro2['FECHA'];

  if ($registro2['HORA']== 24) {
    # code...
    $DatoScript.="{ d: '".$registro2['TH']."', tem: ".$registro2['TEMPERATURA']." }";
  }else {
    # code...
    $DatoScript.="{ d: '".$registro2['TH']."', tem: ".$registro2['TEMPERATURA']." },";
  }

}
$FINALDAY = $ULTIMEDAY+1;
for ($i= $FINALDAY; $i<24 ; $i++) {
  # code...
  $DatoScript.="{ d: '".$ULTMES." ".$i.":00:00', tem: 0 },";

  if ($i==23) {
    # code...
      $FINALDAY = 24;
  }
}
if ($FINALDAY == 24) {
  # code...
  $DatoScript.="{ d: '".$ULTMES." ".$FINALDAY.":00:00', tem: 0 }";
}

    $DatoScript.="
         ],
        xkey: ['d'],
        ykeys: ['tem'],

        labels: ['Temperatura'],

        smooth: false,
        resize: true
    });
    </script> ";
  echo $DatoScript;
  mysqli_close($database);
}
?>
<?php
if ($sqds ==1) {
  # code...

$database = new mysqli($dbserver, $dbuser, $password, $dbname);

if($database->connect_errno) {
  die("No se pudo conectar a la base de datos");
}
$DatoScript = "<script>
  Morris.Line({

    element: 'morris-chart',

    data: [";
$query2 = "SELECT ROUND(AVG(`HUMEDAD`),2) as 'TEMPERATURA',  HOUR(`TIEMPO`) AS 'HORA',
MINUTE(`TIEMPO`) AS 'MIN', `TIEMPO` AS 'TH', DATE(`TIEMPO`) AS 'FECHA'
FROM `STATUS_RECORD`
WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."' AND '".$ValGraf."'
GROUP BY HOUR(TIEMPO)
ORDER BY TIEMPO ASC";

$queryC2 = $database->query($query2);

while ($registro2 = $queryC2->fetch_array( MYSQLI_BOTH)) {
  # code...
  $ULTIMEDAY = $registro2['HORA'];
  $ULTMES = $registro2['FECHA'];

  if ($registro2['HORA']== 24) {
    # code...
    $DatoScript.="{ d:'".$registro2['TH']."', tem: ".$registro2['TEMPERATURA']." }";
  }
/*  elseif ($registro2['DIA'] != 1) {
    # code...
    for ($i=1; $i < $ULTIMEDAY ; $i++) {
      # code...
    }
  }*/
  else {
    # code...
    $DatoScript.="{ d:'".$registro2['TH']."', tem: ".$registro2['TEMPERATURA']." },";
  }


}
$FINALDAY = $ULTIMEDAY+1;
for ($i= $FINALDAY; $i<24 ; $i++) {
  # code...
  $DatoScript.="{ d: '".$ULTMES." ".$i.":00:00', tem: 0 },";

  if ($i==23) {
    # code...
      $FINALDAY = 24;
  }
}
if ($FINALDAY == 24) {
  # code...
  $DatoScript.="{ d: '".$ULTMES." ".$FINALDAY.":00:00', tem: 0 }";

}

    $DatoScript.="
         ],
        xkey: ['d'],
        ykeys: ['tem'],

        labels: ['Humedad Relativa'],

        smooth: false,
        resize: true
    });
    </script> ";
  echo $DatoScript;
  mysqli_close($database);
}?>
    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
<!--    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>

<script src="js/jquery.dataTables.min.js"></script>
<script src="js/jquery-1.12.4.js"></script>
<script>
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>-->
</body>

</html>
