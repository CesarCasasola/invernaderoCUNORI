<?php

ini_set('date.timezone','America/Guatemala');
//Primer ingreso
if (!isset($_POST['graf']) && !isset($_POST['grafd']) && !isset($_POST['grafm'])) {
  # code...
  $anio = date("Y");
  $mes = date("m");

  $ValGraf = $anio.'-'.$mes;
  $fillhourdata = 0;
}//Datos dia Actual -- a-a d-a m-a
elseif ($_POST['graf']==0  && $_POST['grafd']==0 && $_POST['grafm']==0) {
  # code...
  $anio = date("Y");
  $mes = date("m");

  $ValGraf = $anio.'-'.$mes;
  $fillhourdata = $_POST['grafd'];
}//Datos donde fecha actual y dia elegido -- a-a d-e m-a
elseif ($_POST['graf']==0  && $_POST['grafd']!=0 && $_POST['grafm']==0) {
  # code...
  $anio = date("Y");
  $mes = date("m");

    $ValGraf = $anio.'-'.$mes;
    $fillhourdata = $_POST['grafd'];
}//Datos donde anio actual y dia actual y mes elegido -- a-a d-a m-e
elseif ($_POST['graf']==0  && $_POST['grafd']==0 && $_POST['grafm']!=0) {
  # code...
  $anio = date("Y");

    $ValGraf = $anio.'-'.$_POST['grafm'];
    $fillhourdata = $_POST['grafd'];
}//a-e d-a m-a 4
elseif ($_POST['graf']!=0  && $_POST['grafd']==0 && $_POST['grafm']==0) {
  # code...

  $mes = date("m");

    $ValGraf = $_POST['graf'].'-'.$mes;
    $fillhourdata = $_POST['grafd'];
}//a-e d-e m-a 5
elseif ($_POST['graf']!=0  && $_POST['grafd']!=0 && $_POST['grafm']==0) {
  # code...
    $mes = date("m");
      $ValGraf = $_POST['graf'].'-'.$mes;
      $fillhourdata = $_POST['grafd'];
}//a-e d-a m-e 6
elseif ($_POST['graf']!=0  && $_POST['grafd']==0 && $_POST['grafm']!=0) {
  # code...

  $ValGraf = $_POST['graf'].'-'.$_POST['grafm'];
  $fillhourdata = $_POST['grafd'];
}//a-a d-e m-e
elseif ($_POST['graf']==0  && $_POST['grafd']!=0 && $_POST['grafm']!=0) {
  # code...
  $anio = date("Y");
  $ValGraf = $anio.'-'.$_POST['grafm'];
  $fillhourdata = $_POST['grafd'];
}
else {
  # code...
        $ValGraf = $_POST['graf'].'-'.$_POST['grafm'];
        $fillhourdata = $_POST['grafd'];
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script>
      function recargar(){
        location.reload();
      }
    </script>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
      <!--          <a class="navbar-brand" href="index.html">Administrador Invernadero</a>   -->
                <?php
                echo '<a class="navbar-brand" href="index.html">Administrador Invernadero - Fecha: '.$ValGraf.'</a>;'
                 ?>
            </div>

            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>

                  <li class="active">
                      <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-bar-chart-o"></i>Historial Temperatura/Humedad <i class="fa fa-fw fa-caret-down"></i></a>
                      <ul id="demo" class="collapse">
                          <li class="active">
                              <a href="charts.php">Historial Mensual</a>
                          </li>
                          <li>
                              <a href="chartsday.php">Historial Diario</a>
                          </li>
                      </ul>
                  </li>
                  <li>
                          <a href="#"><i class="fa fa-fw fa-sliders"></i> Admin. de Proyectos</a>
                      </li>
              <!--       <li>
                           <a href="blank-page.html"><i class="fa fa-fw fa-file"></i> Blank Page</a>
                    </li>
                    <li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                    </li> -->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Historial Temperatura / Humedad
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-bar-chart-o"></i> Historial Mensual
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <!-- Flot Charts
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="page-header">Flot Charts</h2>
                        <p class="lead">Flot is a pure JavaScript plotting library for jQuery, with a focus on simple usage, attractive looks and interactive features. For full usage instructions and documentation for Flot Charts, visit <a href="http://www.flotcharts.org/">http://www.flotcharts.org/</a>.</p>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Line Graph Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-line-chart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Pie Chart Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-pie-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Multiple Axes Line Graph Example with Tooltips and Raw Data</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-multiple-axes-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                <!-- /.row

                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Moving Line Chart</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-moving-line-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Bar Graph with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div class="flot-chart">
                                    <div class="flot-chart-content" id="flot-bar-chart"></div>
                                </div>
                                <div class="text-right">
                                    <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 /.row -->
                 <!-- Conexion a Base de datos-->
           <?php
                 $dbserver = 'localhost';
                 $dbuser = 'root';
                 $password = '';
                 $dbname = 'sensorial';

                 $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                 if($database->connect_errno) {
                   die("No se pudo conectar a la base de datos");
                 }

                 mysqli_close($database);
          ?>
                <!-- Morris Charts -->
                <div class="row">
                  <form method="post">
                    <select required name="grafm" class="form-control">
                      <option value="0">Mes Actual</option>
                      <?php
                      for ($i=1; $i <= 12; $i++) {
                        # code...
                        switch ($i){
                        case 1:
                          $mesName = "Enero";
                          break;
                        case 2:
                          $mesName = "Febrero";
                          break;
                        case 3:
                          $mesName = "Marzo";
                          break;
                        case 4:
                          $mesName = "Abril";
                          break;
                        case 5:
                          $mesName = "Mayo";
                          break;
                        case 6:
                          $mesName = "Junio";
                          break;
                        case 7:
                          $mesName = "Julio";
                          break;
                        case 8:
                          $mesName = "Agosto";
                          break;
                        case 9:
                          $mesName = "Septiembre";
                          break;
                        case 10:
                          $mesName = "Octubre";
                          break;
                        case 11:
                          $mesName = "Noviembre";
                          break;
                        case 12:
                          $mesName = "Diciembre";
                          break;}
                          if ($i<10) {
                            # code...
                              echo '<option value="0'.$i.'">'.$mesName.'</option>';
                          }
                          elseif ($i>9) {
                            # code...
                            echo '<option value="'.$i.'">'.$mesName.'</option>';
                          }

                      } ?>
                    </select>
                      <select required name="graf" class="form-control">
                        <option value="0">Año Acual</option>
                        <?php
                        $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                        if($database->connect_errno) {
                          die("No se pudo conectar a la base de datos");
                        }

                        $query1 = "SELECT DISTINCT YEAR(A.TIEMPO) AS 'ANIO'  FROM `STATUS_RECORD`A
                                    ORDER BY  YEAR(TIEMPO) ASC";

                        $queryC1= $database->query($query1);

                        while ($registro1 = $queryC1->fetch_array( MYSQLI_BOTH)) {
                          # code...

                          echo '<option value="'.$registro1['ANIO'].'">'.$registro1['ANIO'].'</option>';
                        }
                           mysqli_close($database);
                         ?>
                      </select>
                      </br>
                      <div class="form-group">
                          <center>
                          <label>Filtrado por horas  </label>
                        </center>
                          <center>
                          <label class="radio-inline">
                              <input type="radio" name="grafd" id="optionsRadiosInline1" value="1" >Día
                          </label>
                          <label class="radio-inline">
                              <input type="radio" name="grafd" id="optionsRadiosInline2" value="0" checked>Noche-Día
                          </label>
                          <label class="radio-inline">
                              <input type="radio" name="grafd" id="optionsRadiosInline3" value="2">Noche
                          </label>
                        </center>
                      </div>

                    <center>
                      <input type="submit" name="filtrar" value="Selecionar" class="btn btn-info"/>
                    </center>
                  </form>
                    <div class="col-lg-12">
                        <h2 class="page-header">Grafica Mensual de Temperatura y Humedad</h2>
                        <p class="lead">Las graficas representada por lineas, en el eje Y son valores de Temperatura o Humedad
                          (Los cuales son un promedio de todos los datos recolectados en un dia), en el eje X representa los dias.
                        </p>
                        </br>
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Proyectos en el Mes</h3>
                            </div>
                            <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="table table-hover">
                                      <thead>
                                          <tr>
                                              <th>Nombre del Proyecto</th>
                                              <th>Descripcion</th>
                                              <th>Estado</th>

                                          </tr>
                                      </thead>
                                      <tbody>
                                          <?php
                                          $database = new mysqli($dbserver, $dbuser, $password, $dbname);

                                          if($database->connect_errno) {
                                            die("No se pudo conectar a la base de datos");
                                          }

                                          $query4 = "SELECT DISTINCT A.PROY_CODE AS 'COD', B.NOMBRE AS 'NAME', B.DESCRIPTION AS 'DESCRIP', B.ACTIVO AS 'ACT'
                                          FROM `STATUS_RECORD` A
                                          INNER JOIN PROYECTO B ON B.PROY_CODE = A.PROY_CODE
                                          WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'";

                                          $queryC4 = $database->query($query4);

                                          $row_cnt = $queryC4->num_rows;
                                         if ($row_cnt == 0) {
                                           # code...
                                           $sqds = 0;
                                         }else {
                                           # code...
                                           $sqds = 1;
                                         }

                                          while ($registro4 = $queryC4->fetch_array( MYSQLI_BOTH)) {
                                            # code...
                                            $activo = $registro4['ACT'];

                                            switch ($activo) {
                                              case 1:
                                                # code...
                                                 $valty = "Activo";
                                                break;
                                              case 0:
                                                  # code...
                                                 $valty = "No Activo";
                                                break;

                                            }
                                            echo '<tr>
                                                <td>'.$registro4['NAME'].'</td>
                                                <td>'.$registro4['DESCRIP'].'</td>
                                                <td>'.$valty.'</td>
                                            </tr>';
                                          }
                                          mysqli_close($database);

                                          ?>
                                      </tbody>
                                  </table>
                              </div>
                            </div>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                              <?php
                                switch ($fillhourdata) {
                                  case 0:
                                    # code...
                                    $fillup = "Noche - Día";
                                    break;
                                  case 1:
                                      # code...
                                      $fillup = "Día";
                                    break;
                                  case 2:
                                      # code...
                                      $fillup = "Noche";
                                    break;
                                }
                                echo '<h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Grafica '.$fillup.' del '.$ValGraf.' (Temperatura por dias)  </h3>';
                              ?>
                            </div>
                            <div class="panel-body">
                              <?php
                              if ($sqds == 0) {
                                # code...
                                echo "No existen datos";
                              }elseif ($sqds == 1) {
                                # code...
                                  echo '<div id="morris-area-chart"></div>';
                              }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                              <?php
                              switch ($fillhourdata) {
                                case 0:
                                  # code...
                                  $fillup = "Noche - Día";
                                  break;
                                case 1:
                                    # code...
                                    $fillup = "Día";
                                  break;
                                case 2:
                                    # code...
                                    $fillup = "Noche";
                                  break;
                              }

                                echo '<h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Grafica '.$fillup.' del '.$ValGraf.' (Humedad Relativa por dias) </h3>';
                              ?>
                            </div>
                            <div class="panel-body">
                              <?php
                              if ($sqds == 0 ) {
                                # code...
                                echo "No existen datos";
                              }elseif ($sqds == 1) {
                                # code...
                                  echo '<div id="morris-chart"></div>';
                              }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Donut Chart Example</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart"></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Line Graph Example with Tooltips</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-line-chart"></div>

                            </div>
                        </div>
                    </div>

                </div>-->
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->

    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>

<!--    <script src="js/plugins/morris/morris-data.js"></script> -->
<?php
if ($sqds ==1) {
  # code...

$database = new mysqli($dbserver, $dbuser, $password, $dbname);

if($database->connect_errno) {
  die("No se pudo conectar a la base de datos");
}
$DatoScript = "<script>
  Morris.Line({

    element: 'morris-area-chart',

    data: [";

if ($fillhourdata == 0) {
  # code...

$query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
FROM `STATUS_RECORD`
WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
GROUP BY DATE(TIEMPO)
ORDER BY TIEMPO ASC";
}
elseif ($fillhourdata == 1) {
  # code...
/*  $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
  DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
  FROM `STATUS_RECORD`
  WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
  AND TIME(`TIEMPO`)>= '6:00:00' AND TIME(`TIEMPO`)<= '17:59:59'
  GROUP BY DATE(TIEMPO)
  ORDER BY TIEMPO ASC"; */
  $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
    DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
    FROM `STATUS_RECORD`
    WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
    AND TIME(`TIEMPO`)>= '6:00:00' AND TIME(`TIEMPO`)<= '17:59:59'
    GROUP BY DATE(TIEMPO)
    ORDER BY TIEMPO ASC";
}
elseif ($fillhourdata == 2) {
  # code...
  /*  $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
    DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO', TIME(`TIEMPO`)
    FROM `STATUS_RECORD`
    WHERE  (DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31')
    AND (TIME(`TIEMPO`)<= '5:59:59' OR TIME(`TIEMPO`)>= '18:00:00')
    GROUP BY DATE(TIEMPO)
    ORDER BY TIEMPO ASC";*/

     $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
       DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO', TIME(`TIEMPO`)
       FROM `STATUS_RECORD`
       WHERE  (DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31')
       AND (TIME(`TIEMPO`)<= '5:59:59' OR TIME(`TIEMPO`)>= '18:00:00')
       GROUP BY DATE(TIEMPO)
       ORDER BY TIEMPO ASC";
}
$queryC2 = $database->query($query2);

$row_cnt2 = $queryC2->num_rows;

if ($row_cnt2 == 0) {
  # code...
  for ($i=1; $i <32 ; $i++) {
    # code...
      $DatoScript.="{ d: '".$ValGraf."-".$i."', tem: 0 },";
  }
}else {
  # code...

while ($registro2 = $queryC2->fetch_array( MYSQLI_BOTH)) {
  # code...
  $ULTIMEDAY = $registro2['DIA'];
  $ULTMES = $registro2['ANIO']."-".$registro2['MES'];

  if ($registro2['DIA']== 31) {
    # code...
    $DatoScript.="{ d: '".$registro2['FECHA']."', tem: ".$registro2['TEMPERATURA']." }";
  }else {
    # code...
    $DatoScript.="{ d: '".$registro2['FECHA']."', tem: ".$registro2['TEMPERATURA']." },";
  }

}
$FINALDAY = $ULTIMEDAY+1;
for ($i= $FINALDAY; $i<31 ; $i++) {
  # code...
  $DatoScript.="{ d: '".$ULTMES."-".$i."', tem: 0 },";
}
if ($FINALDAY == 31) {
  # code...
  $DatoScript.="{ d: '".$ULTMES."-".$i."', tem: 0 }";
}
}
    $DatoScript.="
         ],
        xkey: 'd',
        ykeys: ['tem'],

        labels: ['Temperatura'],

        smooth: false,
        resize: true
    });
    </script> ";
  echo $DatoScript;
  mysqli_close($database);
}
?>
<?php
if ($sqds ==1) {
  # code...

$database = new mysqli($dbserver, $dbuser, $password, $dbname);

if($database->connect_errno) {
  die("No se pudo conectar a la base de datos");
}
$DatoScript = "<script>
  Morris.Line({

    element: 'morris-chart',

    data: [";
if ($fillhourdata == 0) {
  # code...

$query2 = "SELECT  ROUND(AVG(`HUMEDAD`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
FROM `STATUS_RECORD`
WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
GROUP BY DATE(TIEMPO)
ORDER BY TIEMPO ASC";
}
elseif ($fillhourdata == 1) {
  # code...
  /*  $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
    DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
    FROM `STATUS_RECORD`
    WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
    AND TIME(`TIEMPO`)>= '6:00:00' AND TIME(`TIEMPO`)<= '17:59:59'
    GROUP BY DATE(TIEMPO)
    ORDER BY TIEMPO ASC"; */
    $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
      DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO'
      FROM `STATUS_RECORD`
      WHERE DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31'
      AND TIME(`TIEMPO`)>= '6:00:00' AND TIME(`TIEMPO`)<= '17:59:59'
      GROUP BY DATE(TIEMPO)
      ORDER BY TIEMPO ASC";
}
elseif ($fillhourdata == 2) {
  # code...
/*  $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
  DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO', TIME(`TIEMPO`)
  FROM `STATUS_RECORD`
  WHERE  (DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31')
  AND (TIME(`TIEMPO`)<= '5:59:59' OR TIME(`TIEMPO`)>= '18:00:00')
  GROUP BY DATE(TIEMPO)
  ORDER BY TIEMPO ASC";*/

   $query2 = "SELECT  ROUND(AVG(`TEMPERATURA`),2) as 'TEMPERATURA',  DATE(`TIEMPO`) AS 'FECHA',
     DAY(`TIEMPO`) AS 'DIA', MONTH(`TIEMPO`) AS 'MES', YEAR(`TIEMPO`) AS 'ANIO', TIME(`TIEMPO`)
     FROM `STATUS_RECORD`
     WHERE  (DATE(TIEMPO) BETWEEN '".$ValGraf."-01' AND '".$ValGraf."-31')
     AND (TIME(`TIEMPO`)<= '5:59:59' OR TIME(`TIEMPO`)>= '18:00:00')
     GROUP BY DATE(TIEMPO)
     ORDER BY TIEMPO ASC";
}
$queryC2 = $database->query($query2);
$row_cnt3 = $queryC2->num_rows;

if ($row_cnt3 == 0) {
  # code...
  for ($i=1; $i <32 ; $i++) {
    # code...
      $DatoScript.="{ d: '".$ValGraf."-".$i."', tem: 0 },";
  }
}else {
  # code...

while ($registro2 = $queryC2->fetch_array( MYSQLI_BOTH)) {
  # code...
  $ULTIMEDAY = $registro2['DIA'];
  $ULTMES = $registro2['ANIO']."-".$registro2['MES'];

  if ($registro2['DIA']== 31) {
    # code...
    $DatoScript.="{ d:'".$registro2['FECHA']."', tem: ".$registro2['TEMPERATURA']." }";
  }
/*  elseif ($registro2['DIA'] != 1) {
    # code...
    for ($i=1; $i < $ULTIMEDAY ; $i++) {
      # code...
    }
  }*/
  else {
    # code...
    $DatoScript.="{ d:'".$registro2['FECHA']."', tem: ".$registro2['TEMPERATURA']." },";
  }


}
$FINALDAY = $ULTIMEDAY+1;
for ($i= $FINALDAY; $i<31 ; $i++) {
  # code...
  $DatoScript.="{ d:'".$ULTMES."-".$i."', tem: 0 },";
}
if ($FINALDAY == 31) {
  # code...
  $DatoScript.="{ d:'".$ULTMES."-".$i."', tem: 0 }";
}
}
    $DatoScript.="
         ],
        xkey: 'd',
        ykeys: ['tem'],

        labels: ['Humedad Relativa'],

        smooth: true,
        resize: true
    });
    </script> ";
  echo $DatoScript;
  mysqli_close($database);
}
?>
    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
<!--    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>
-->
</body>

</html>
